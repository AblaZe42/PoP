Aleaxander Husted

naviger til src
skriv i terminal: "dotnet fsi .\simulate.fs .\testSimulate.fsx"